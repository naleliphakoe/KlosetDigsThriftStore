<?php
$conn = new mysqli('localhost','root','','KlosetDigsdb');
if ($conn->connect_error) {
    echo 'CONNECT_ERROR: ' . $conn->connect_error;
    exit(1);
}
$res = $conn->query('SHOW TABLES');

if (!$res) {
    echo 'QUERY_ERROR: ' . $conn->error;
    exit(1);
}
while ($row = $res->fetch_row()) {
    echo $row[0] . "\n";
}
?>